package com.hibernate.firstLevelCache;

import org.hibernate.Session;

import com.hibernate.test.namedquery.DepartmentEntity;
import com.hibernate.test.util.HibernateUtil;

public class FirstLevelCache {
	public static void main(String[] args) {
		// Open the hibernate session
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		Session sessionTemp = HibernateUtil.getSessionFactory().openSession();
		sessionTemp.beginTransaction();

		try {
			// fetch the department entity from database first time
			System.out.println("First time Call:");
			DepartmentEntity department = (DepartmentEntity) session.load(DepartmentEntity.class, new Integer(1));
			System.out.println(department.getName());

			System.out.println("\nSecond time Call with same session:");
			// fetch the department entity again
			department = (DepartmentEntity) session.load(DepartmentEntity.class, new Integer(1));
			System.out.println(department.getName());

			System.out.println("\nRemoving cache objects from first level cache");
			session.evict(department);
		    //session.clear();
			
			System.out.println("\nThird time Call with same session after removing cache:"); 
		    department = (DepartmentEntity) session.load(DepartmentEntity.class, new Integer(1));
		    System.out.println(department.getName());
		    
			System.out.println("\nFourth time call different session:");
			department = (DepartmentEntity) sessionTemp.load(DepartmentEntity.class, new Integer(1));
			System.out.println(department.getName());

		} finally {
			session.getTransaction().commit();
			HibernateUtil.shutdown();

			sessionTemp.getTransaction().commit();
			HibernateUtil.shutdown();
		}

	}
}
