package com.hibernate;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

public class GetColumnNamesFromResultSet_Oracle {
	 public static Connection getConnection() throws Exception {
		    String driver = "oracle.jdbc.driver.OracleDriver";
		    String url = "jdbc:oracle:thin:@localhost:1521:xe";
		    String username = "test";
		    String password = "test";

		    Class.forName(driver);
		    Connection conn = DriverManager.getConnection(url, username, password);
		    return conn;
		  }

		  public static void getColumnNames(ResultSet rs) throws SQLException {
		    if (rs == null) {
		      return;
		    }
		    // get result set meta data
		    ResultSetMetaData rsMetaData = rs.getMetaData();
		    int numberOfColumns = rsMetaData.getColumnCount();
		    while(rs.next()) {
		    	for(int i=1;i<=numberOfColumns;i++) {
		    		System.out.print(rsMetaData.getColumnName(i)+"("+rsMetaData.getColumnTypeName(i)+") ="+rs.getString(i)+"  ");
		    	}
		    	System.out.println();
		    	
		    }
		  }		   
		  public static void main(String[] args) {
		    Connection conn = null;
		    Statement stmt = null;
		    ResultSet rs = null;
		    try {
		      conn = getConnection();
		      // prepare query
		      String query = "select id, email,first_name,last_name from employee";
		      // create a statement
		      stmt = conn.createStatement();
		      // execute query and return result as a ResultSet
		      rs = stmt.executeQuery(query);
		      // get the column names from the ResultSet
		      getColumnNames(rs);
		    } catch (Exception e) {
		      e.printStackTrace();
		    } finally {
		      // release database resources
		      try {
		        rs.close();
		        stmt.close();
		        conn.close();
		      } catch (SQLException e) {
		        e.printStackTrace();
		      }
		    }
		  }
		}
		           
		         