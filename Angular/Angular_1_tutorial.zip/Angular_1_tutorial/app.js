var app = angular.module('DemoApp',[]);

	app.controller('DemoController', function($scope){
     $scope.num1=0;
	$scope.num2=0
	$scope.manipulate = function(){
	  var a = Number($scope.num1 || 0);
      var b = Number($scope.num2 || 0);
		$scope.sum = a+b;
		$scope.substract = a-b;
		$scope.multiply = a*b;
		$scope.division =a/b;
	}
	  	  
	});