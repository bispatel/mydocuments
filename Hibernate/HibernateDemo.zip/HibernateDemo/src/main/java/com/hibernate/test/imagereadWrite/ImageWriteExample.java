package com.hibernate.test.imagereadWrite;

import java.io.File;

import org.hibernate.Session;

import com.hibernate.test.demo.ImageWrapper;
import com.hibernate.test.util.HibernateUtil;

public class ImageWriteExample {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();

		File file = new File("img/Indane.png");
		byte[] imageData = new byte[(int) file.length()];

		ImageWrapper image = new ImageWrapper();
		image.setImageName("test.jpeg");
		image.setData(imageData);

		session.save(image); // Save the data

		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
}
