package com.hibernate.test.namedquery;


import org.hibernate.Query;
import org.hibernate.Session;

import com.hibernate.test.util.HibernateUtil;

public class TestHibernateNamedQuery {
	public static void main(String[] args)
    {
        //Open the hibernate session
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();
        try
        {
            //Update record using named query
            Query query = session.getNamedQuery(DepartmentEntity.UPDATE_DEPARTMENT_BY_ID)
                                        .setInteger("id", 1)
                                        .setString("name", "Finance");
            query.executeUpdate();
             
            //Get named query instance
            query = session.getNamedQuery(DepartmentEntity.GET_DEPARTMENT_BY_ID)
                                        .setInteger("id", 1);
            //Get all departments (instances of DepartmentEntity)
            DepartmentEntity department = (DepartmentEntity) query.uniqueResult();
            if(department!=null) {
            	System.out.println(department.getName());	
            }
            
        }
        finally
        {
            session.getTransaction().commit();
            HibernateUtil.shutdown();
        }
    }
}
