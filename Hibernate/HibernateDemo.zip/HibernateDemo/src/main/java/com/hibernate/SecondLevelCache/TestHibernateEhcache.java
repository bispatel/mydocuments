package com.hibernate.SecondLevelCache;

import org.hibernate.Session;

public class TestHibernateEhcache {
	public static void main(String[] args)
    {
      //  storeData();
         
        try
        {
            //Open the hibernate session
            Session session = HibernateUtilFor2ndLevelCache.getSessionFactory().openSession();
            session.beginTransaction();
            
            System.out.println("First Time Call.");
            //fetch the department entity from database first time
            DepartmentEntity department = (DepartmentEntity) session.load(DepartmentEntity.class, new Integer(1));
            System.out.println(department.getName());
             
            System.out.println("\nSecond Time Call. Same Session:");
            //fetch the department entity again; Fetched from first level cache
            department = (DepartmentEntity) session.load(DepartmentEntity.class, new Integer(1));
            System.out.println(department.getName());
             
            //Let's close the session
            session.getTransaction().commit();
            session.close();
             
           
            //Try to get department in new session
            Session anotherSession = HibernateUtilFor2ndLevelCache.getSessionFactory().openSession();
            anotherSession.beginTransaction();
            System.out.println("\nThird Time Call. Different Session. Fetching from 2nd level Cache:");
            //Here entity is already in second level cache so no database query will be hit
            department = (DepartmentEntity) anotherSession.load(DepartmentEntity.class, new Integer(1));
            System.out.println(department.getName());
             
            anotherSession.getTransaction().commit();
            anotherSession.close();
        }
        finally
        {
            System.out.println(HibernateUtilFor2ndLevelCache.getSessionFactory().getStatistics().getEntityFetchCount()); //Prints 1
            System.out.println(HibernateUtilFor2ndLevelCache.getSessionFactory().getStatistics().getSecondLevelCacheHitCount()); //Prints 1
             
            HibernateUtilFor2ndLevelCache.shutdown();
        }
    }
     
    private static void storeData()
    {
        Session session = HibernateUtilFor2ndLevelCache.getSessionFactory().openSession();
        session.beginTransaction();
         
        DepartmentEntity department = new DepartmentEntity();
        department.setName("Human Resource");
         
        session.save(department);
        session.getTransaction().commit();
    }
}
