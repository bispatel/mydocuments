package com.hibernate.test.imagereadWrite;

import java.io.File;
import java.io.FileOutputStream;

import org.hibernate.Session;

import com.hibernate.test.demo.ImageWrapper;
import com.hibernate.test.util.HibernateUtil;

public class ImageReadExample {

	public static void main(String[] args) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		 
		ImageWrapper imgNew = (ImageWrapper)session.get(ImageWrapper.class, 3);
		byte[] bAvatar = imgNew.getData();
		 
		try{
		    FileOutputStream fos = new FileOutputStream(new File("D:\\test.png"));
		    fos.write(bAvatar);
		    fos.close();
		}catch(Exception e){
		    e.printStackTrace();
		}
		 
		session.getTransaction().commit();
		HibernateUtil.shutdown();
	}
}
