package com.hibernate.test.objectEquality;

import org.hibernate.Session;

import com.hibernate.test.demo.EmployeeEntity;
import com.hibernate.test.util.HibernateUtil;

public class ObjectEqualityInSession {
	public static void main(String[] args)
	{
	    Session sessionOne = HibernateUtil.getSessionFactory().openSession();
	    sessionOne.beginTransaction();
	 
	    // Create new Employee object
	    EmployeeEntity emp = new EmployeeEntity();
	    emp.setFirstName("Lokesh");
	    emp.setLastName("Gupta");
	    emp.setEmail("test@gmail.com");
	    //Save employee
	    sessionOne.save(emp);
	 
	    sessionOne.getTransaction().commit();
	 
	    //Get employee id
	    Integer genEmpId = emp.getEmployeeId();
	 
	    //New session where we will fetch the employee two times and compare the objects
	    Session sessionTwo = HibernateUtil.getSessionFactory().openSession();
	    sessionTwo.beginTransaction();
	 
	    EmployeeEntity employeeObj1 = (EmployeeEntity) sessionTwo.get(EmployeeEntity.class, genEmpId);
	    EmployeeEntity employeeObj2 = (EmployeeEntity) sessionTwo.get(EmployeeEntity.class, genEmpId);
	    EmployeeEntity employeeObj3 = (EmployeeEntity) sessionOne.get(EmployeeEntity.class, genEmpId);
	 
	    //Checking equality
	    System.out.println("Same Session:"+(employeeObj1 == employeeObj2));
	    System.out.println("Different Session1:"+(employeeObj1 == employeeObj3));
	    System.out.println("Different Session2:"+(employeeObj2 == employeeObj3));
	    
	 
	    HibernateUtil.shutdown();
	}
}
